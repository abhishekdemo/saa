const {esp} = require('./esp8266')

esp.on("sensorValue",(err,value)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log(value);
})

// TODO Write HTTP or CoAP or Websocket clients to exchange the data
// Example send it to ThingSpeak or Dweet platforms