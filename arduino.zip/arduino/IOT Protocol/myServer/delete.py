# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "https://api.thingspeak.com:"
PORT = "443"
CHANNEL_ID ="1979353"
KEY="UV5K5CP89KQLWK3K";
PATH = "/channels/"+CHANNEL_ID+ ".csv?api_key=" +KEY


response = requests.delete(HOST + PORT + PATH )

print(response.text)