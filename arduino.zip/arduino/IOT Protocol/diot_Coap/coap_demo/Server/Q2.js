
var express = require('express');
var app = express();
const bodyParser = require('body-parser');  
const cors = require('cors');   

app.use(cors({
  
    origin: '*'
}));


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


let courses = [
           {id:1,name:'Java',Auther:'James Gosling'},
           {id:2,name:'AJAX',Auther:'Euripides'},
		     {id:3,name:'Angular',Auther:'Deborah Kurata'}];

app.get('/', function(req, res){
   let str = "<h1>Hello World </h1>"
   str += "Do you want to <a href='AddBook.html'>Add new Book</a>"
   res.send(str);
});

app.get('/AddBook.html', function(req, res){
   res.sendFile('AddBook.html' , { root : __dirname});
});

app.get('/api/Book', function(req, res){

   res.send(courses);
});


app.get('/api/Book/:id', function(req, res){
   var course;
   for(c in courses){
	   if(courses[c].id == parseInt(req.params.id)){
		   console.log("found ");
		   course = courses[c];
	   }
   }
   res.send(course);
});

app.post('/api/Book',function(req,res){
      console.log(req.body)
      let obj = req.body
      obj.id = courses.length+1
      console.log(obj)
		courses.push(obj);
	res.send("Added Book : " + JSON.stringify(obj));
});
	
app.delete('/api/Book/:id', function(req, res){
   var course = {}, index=0;
   for(c in courses){
	   if(courses[index].id == parseInt(req.params.id)){
		   console.log("Book found for delete  " + courses[index].toString(), index);
		   course = courses[index];
         break;
	   }
      index++;
   }
   courses.splice(index,1)
   res.send(course)
   
});

app.listen(3000, function(){
   console.log("Server is running")
});












