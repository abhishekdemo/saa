#Demo program to understand json

import json
info = {
    "insitute":"CDAC",
    "year":2022,
    "student":True,
    "classes":("DIoT","DAC"),
    "passout":None,
    "subjects":[
        {"name":"IoT","duration":2},
        {"name":"Embedded","duration":1}
    ]
}

myJSONString = json.dumps(info)

myJson= json.loads(myJSONString)
print(type(myJson))