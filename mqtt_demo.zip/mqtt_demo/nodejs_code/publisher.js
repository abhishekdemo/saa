// Program to publish data to Broker on TOPIC
const mqtt = require('mqtt');

const HOST = 'mqtt://localhost:';
const PORT = '1883';

const publisher = mqtt.connect(HOST + PORT);

// MQTT Topic to Publish data to
const TOPIC = 'cdac/diot';

// Event to Check BROKER connection
publisher.on('connect',()=>{
    
    console.log("Connected to MQTT Broker!");

    // Publish the data
    publisher.publish(TOPIC,'{"sensor":24.5}',()=>{
        console.log("Message published");
    })
})


